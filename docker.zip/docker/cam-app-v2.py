# STREAMLIT APP - EZUA END2END DEMO V2
# created by 2024 (c) by Dirk Derichsweiler
#
# this app is to demonstrate the use of HPE Ezmeral Unified Analytics Software for image classification and is using EzPresto to get the required data fields from the privous created datasets.
#
# do not hesitate to contact me:
# dirk.derichsweiler@hpe.com
#

# Import neccessary libraries
import streamlit as st
import logging
import urllib3
import os
import configparser
import requests
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from PIL import Image
import numpy as np
import json
import pandas as pd
from datetime import datetime
import boto3
from tensorflow import keras
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.models import load_model
# Added VC - New library
from sqlalchemy import create_engine, text

streamlit_title = "Ezmeral Unified Analytics Demo"

# initialize logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logging.info('CAM-APP-V2 created by Dirk Derichsweiler: Starting the cam-app application...')

# turn off InsecureRequestWarning
urllib3.disable_warnings()


# set variables
config_file = 'config.ini'
custom_config_file = 'config-custom.ini'

# check if custom config file exists!!
if os.path.exists(custom_config_file):
    logging.info("custom config file exists")
    config_file = custom_config_file   
else:
    logging.info("custom config file does not exist!")
    logging.info("using default config file")


if os.path.exists(config_file):
    logging.info("config file exists")
else:
    logging.error("config file does not exist")



# Load the configuration file
config = configparser.ConfigParser()
config.read(config_file)


# check if s3_upload_enabled is set to True
try:
    s3_upload_enabled = config.get('config', 's3_upload_enabled')
    if s3_upload_enabled.lower() == "true":
        s3_upload_enabled = True
    else:
        s3_upload_enabled = False
except Exception as e:
    logging.error(f"Error reading s3_upload_enabled: {e}")
else:
    logging.info("s3_upload_enabled variable loaded successfully")

if s3_upload_enabled:
    logging.info("s3_upload_enabled is True")
    # source upload_s3_variables
    try:
        upload_access_key_id = config.get('upload_s3_login', 'upload_s3_access_key_id')
        upload_secret_access_key = config.get('upload_s3_login', 'upload_s3_secret_access_key')
        upload_url = config.get('upload_s3_login', 'upload_s3_url')
        upload_bucket = config.get('upload_s3_login', 'upload_s3_bucket')
        upload_path = config.get('upload_s3_login', 'upload_s3_path')
    except Exception as e:
        logging.error(f"Error reading upload_s3_variables: {e}")
    else:
        logging.info("S3 Upload is enabled. ")
else:
    logging.info("s3_upload_enabled is False")


# check the selected model
try:
    selected_model = config.get('config', 'selected_model')
except Exception as e:
    logging.error(f"Error reading selected_model: {e}")
else:
    selected_model = "model-" + selected_model
    logging.info(f"selected_model loaded successfully: {selected_model}")


# source labels from config file
try:
    labels_raw = config.get(selected_model, 'labels')
    labels_raw = labels_raw.replace("\n", "")
    labels = labels_raw.split(",")
except Exception as e:
    logging.error(f"Error reading labels: {e}")
else:
    logging.info(f"labels: {labels} loaded successfully")




# source price from config file
try:
    prices_raw = config.get(selected_model, 'price')
    prices_raw = prices_raw.replace("\n", "")
    prices = prices_raw.split(",")
except Exception as e:
    logging.error(f"Error reading price: {e}")
else:
    logging.info("prices loaded successfully")

if len(labels) != len(prices):
    logging.warning("Error: labels and prices have different length")



try:
    kserve_enabled = config.get(selected_model, 'use_kserve')
    if kserve_enabled.lower() == "true":
        kserve_enabled = True
        logging.info("kserve_enabled is True")
    else:
        kserve_enabled = False
        logging.info("kserve_enabled is False")
except Exception as e:
    logging.error(f"Error reading kserve_enabled: {e}")
else:
    logging.info(f"kserve_enabled is set to: {kserve_enabled}")

# check if kserve is set to true
if kserve_enabled:
    try:
        model_user = config.get(selected_model, 'model_username')
        model_password = config.get(selected_model, 'model_password')
        model_url = config.get(selected_model, 'model_url')
        keycloak_url = config.get(selected_model, 'keycloak_url')
        # Added VC - Added Table name
        table_name = config.get(selected_model, 'table_name')
    except Exception as e:
        logging.error(f"Error reading model_user and model_password: {e}")
    else:
        logging.info("model_user and model_password loaded successfully")
else:
    try:
        offline_s3_access_key_id = config.get(selected_model, 'offline_s3_access_key_id')
        offline_s3_secret_access_key = config.get(selected_model, 'offline_s3_secret_access_key')
        offline_s3_url = config.get(selected_model, 'offline_s3_url')
        offline_s3_bucket = config.get(selected_model, 'offline_s3_bucket')
        offline_s3_path = config.get(selected_model, 'offline_s3_path')
        offline_s3_model = config.get(selected_model, 'offline_s3_model')
    except Exception as e:
        logging.error(f"Error reading offline_s3_variables: {e}")
    else:
        s3 = boto3.client(
            's3',
            aws_access_key_id=offline_s3_access_key_id,
            aws_secret_access_key=offline_s3_secret_access_key,
            endpoint_url=offline_s3_url,
            verify=False  # Disable SSL certificate verification
        )
        try:
            if not os.path.exists(offline_s3_model):
                logging.info(f"Downloading model {offline_s3_bucket, offline_s3_path+offline_s3_model, offline_s3_model}")
                s3.download_file(offline_s3_bucket, offline_s3_path+offline_s3_model, offline_s3_model)
            else:
                logging.info(f"Model {offline_s3_model} already exists")
        except Exception as e:
            logging.error(f"Error downloading model: {e}")
        else:
            logging.info(f"Model {offline_s3_model} downloaded successfully")

        try:
            logging.info(f"Loading model {offline_s3_model}")
            model = keras.models.load_model(offline_s3_model)
        except Exception as e:
            logging.error(f"Error loading model: {e}")
        else:
            logging.info(f"Model {offline_s3_model} loaded successfully")
    



# make any grid with a function
def make_grid(cols,rows):
    grid = [0]*cols
    for i in range(cols):
        with st.container():
            grid[i] = st.columns(rows, gap="small")
    return grid


def check_config_sections(ini_file):
    """
    Checks which sections are present with the prefix 'model-' in the configuration file.

    Args:
        config (ConfigParser): The configuration file.

    Returns:
        list: list names of the sections.
    """
    parser = configparser.ConfigParser()
    parser.read(ini_file)
    models = []
    for section in parser.sections():
        if section.startswith('model-'):
            models.append(section[6:])
    return models



def get_access_and_refresh_tokens(model_user, model_password, keycloak_uri):
    """
    Retrieves access and refresh tokens from Keycloak using the provided credentials.

    Args:
        model_user (str): The username.
        model_password (str): The password.
        keycloak_url: The Keycloak URL.

    Returns:
        dict: A dictionary containing the access_token and refresh_token.
    """
    client_id = "ua-grant"

    # Create the data payload
    data = {
        "username": model_user,
        "password": model_password,
        "grant_type": "password",
        "client_id": client_id
    }

    try:
        # Make the POST request
        response = requests.post(keycloak_uri, data=data, verify=False)  # Use verify=False for self-signed certificates
        response_json = response.json()

        # Extract access_token and refresh_token
        access_token = response_json.get("access_token")
        refresh_token = response_json.get("refresh_token")
        logging.info("Tokens retrieved successfully")
# Added VC - Changed the return function to only return the auth_token
#        return {"access_token": access_token, "refresh_token": refresh_token}
        return access_token

    except Exception as e:
        logging.error(f"Error fetching tokens: {e}")
        return None



def format_data(data):
    # Convert the NumPy array to a list
    data_list = data.tolist()
    
    # Format the list as a JSON string
    data_formatted = json.dumps(data_list)
    
    # Create a JSON request string with the formatted data
    json_request = '{{ "instances" : {} }}'.format(data_formatted)
    
    return json_request


# Define the function that predicts the class label of an input image
def predict(image):
    logging.info("Predicting the class label of the input image...")

    # Preprocess the image
    image = image.resize((224, 224))
    image = img_to_array(image)
    image = np.expand_dims(image, axis=0)
    image = image / 255
    preprocessed_image = image

    if kserve_enabled:
        # preprocessed_image = preprocess_image(image)
        json_request = format_data(image)

        url = model_url
        logging.info(f"URL: {url}")


        # Make the POST request
        response = requests.post(url, data=json_request, verify=False)

        # If the response is in JSON format, you can decode it
        if response.headers.get("Content-Type") == "application/json":
            response_data = response.json()
            predictions = response_data['predictions']
            formatted_predictions = [[round(pred, 2) for pred in prediction] for prediction in predictions]
            
            # find the highest prediction and print the label
            highest_prediction = np.argmax(predictions)
            highest_value = np.max(predictions)

            logging.info("Prediction found an: " + labels[highest_prediction])
            logging.info("Prediction value: " + str(highest_value))
    else:
        predictions = model.predict(preprocessed_image)
        formatted_predictions = [[round(pred, 2) for pred in prediction] for prediction in predictions]

        # find the highest prediction and print the label
        highest_prediction = np.argmax(predictions)
        highest_value = np.max(predictions)
        logging.info("Formatted predictions: " + str(formatted_predictions))
        logging.info("Prediction found an: " + labels[highest_prediction])
        logging.info("Prediction value: " + str(highest_value))

    return labels[highest_prediction], highest_value


# Added VC  - Updated the whole function
def query_presto(product):
    # This function retrieves the unit price of a product from a Presto database.
    # It uses Keycloak for authentication to obtain an access token, which is then used to create a session
    # for executing the SQL query. The SQL query retrieves the unit price of the specified product from the
    # specified table in the Presto database.
    
    # Update the auth token using the access token obtained from Keycloak
    auth_token = get_access_and_refresh_tokens(model_user, model_password, keycloak_uri)
    
    # Create a new session with the updated authentication token
    session = requests.Session()
    session.headers["Authorization"] = "Bearer " + f"{auth_token}"

    # Create a SQLAlchemy engine to connect to the Presto database
    engine = create_engine(
        "presto://ezpresto-sts-mst-0.ezpresto-svc-hdl.ezpresto.svc.cluster.local:8081",
        connect_args={
            "protocol": "https",
            "requests_kwargs": {"verify": False},
            "requests_session": session,
        },
    )

    # Define the SQL query to retrieve the unit price of the specified product from the specified table
    QUERY = f"SELECT UNITPRICE FROM {table_name} WHERE PRODUCT = '{product}' LIMIT 1"

    # Execute the SQL query and retrieve the result
    with engine.connect() as connection:
        with connection.begin():
            result = connection.execute(text(QUERY))
            for row in result:
                # Extract the unit price (a number) from the query result
                number = float(row[0])
                
    # Return the extracted unit price
    return number

def append_row(df, row):
    return pd.concat([
                df, 
                pd.DataFrame([row], columns=row.index)]
           ).reset_index(drop=True)


def upload_file_to_s3(file_path):
    
    # Get the current date and time
    current_datetime = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    
    # Extract the filename from the file path
    file_name = file_path.split('/')[-1]
    
    # Append the date and time suffix to the filename
    new_file_name = f"{current_datetime}_{file_name}"

    
    try:
        s3 = boto3.client(
            's3',
            aws_access_key_id=upload_access_key_id,
            aws_secret_access_key=upload_secret_access_key,
            endpoint_url=upload_url,
            verify=False  # Disable SSL certificate verification
        )
        s3.upload_file(file_path, upload_bucket, upload_path + new_file_name)

        logging.info("File " + new_file_name + " uploaded successfully!")
    except Exception as e:
        logging.error(f"Error uploading file: {e}")



def app():
    file_name='data.csv' 
    price = 0


    if "load_state" not in st.session_state:

        # Download the file once
        st.session_state.load_state = False
        st.session_state['price'] = 0
        df = pd.DataFrame(columns=('Amount', 'Product', 'price'))
        df.to_csv(file_name, encoding='utf-8', index=False)
    else:
        df=pd.read_csv('data.csv')
        price=st.session_state['price']  
 

    st.set_page_config(           
        page_title=streamlit_title,
        layout="wide",
        initial_sidebar_state="collapsed",
        menu_items={
            'Get Help': 'https://help.mydirk.de',
            'Report a bug': "https://bug.mydirk.de",
            'About': "Ezmeral Unfied Analytics Demo. Do not hesitate to contact me: dirk.derichsweiler@hpe.com"
        }
    )

    with st.sidebar:
        st.title("Ezmeral Unified Analytics Demo")
        st.write("")

        st.write("This app is to demonstrate the use of HPE Ezmeral Unified Analytics Software for image classification.")
        st.write("do not hesitate to contact me for further information: Dirk Derichsweiler, dirk.derichsweiler@hpe.com")
        st.write("")


        # create a select box to select the model on the sidebarmenu
        model_names = ''
        model_names = check_config_sections(config_file)
        logging.info(f"Model names: {model_names}")
        add_select = st.selectbox("current Model:", model_names, index=model_names.index(selected_model[6:]))
        logging.info(f"model: {add_select} defined as the default model")
        config.set('config','selected_model', add_select)
        with open(config_file, 'w') as configfile:
            config.write(configfile)

        st.write("")
        st.write("Here you can upload your config.ini file:")
        st.file_uploader("Upload", type=["ini"], help="Upload your config.ini file", on_change=None, key="my_file_uploader")

        if st.session_state["my_file_uploader"]:
            uploaded_file = st.session_state["my_file_uploader"].read()
            with open("config-custom.ini", "wb") as f:
                f.write(uploaded_file)
               


        st.write("")


    # Hide mainmenu and footer
    #               #MainMenu {visibility: hidden;}
    hide_streamlit_style = """
                <style>
                footer {visibility: hidden;}
                </style>
                """
    st.markdown(hide_streamlit_style, unsafe_allow_html=True)


    image=Image.open('hpelogo.png')
    headline = make_grid(1,4)       
    with headline[0][3]:
        st.image(image, width=300)
    with headline[0][0]:
        st.title(streamlit_title)
    #st.write('This app is to demonstrate the use of HPE Ezmeral Unified Analytics Software for image classification and is using EzPresto to get the required data fields from the privous created datasets.')
    st.write('V2.01 created (c) 2024 by Dirk Derichsweiler')
    st.divider()
    grid = make_grid(3,3)
    with grid[0][2]:
        placeholder = st.empty()
        placeholder.data_editor(df,use_container_width=True)
    with grid[2][2]:             
        placeholder_price = st.empty()        
        total = df['price'].sum()
        total = "{:.2f}".format(total)
        placeholder_price.title(str("Total: " + str(total) + " USD"))

    st.divider()

    #take_photo = grid[0][0].back_camera_input("live camera feed", label_visibility="collapsed", key="camera-1")
    take_photo = grid[0][0].camera_input("Take a picture")

    if take_photo is not None:
        image = Image.open(take_photo)
        grid[0][1].image(image, caption='Uploaded image', use_column_width=True)

        image.convert('RGB')
        image.save('image.jpg', format='JPEG', quality=90)

        prediction, predication_value = predict(image)

        # st.divider()
        if prediction != 'ezmeral':
            # Added VC - Formatting
            st.metric(label="EZPresto Query (Presto)", value=f'SELECT UNITPRICE FROM {table_name} WHERE PRODUCT = "' + prediction + '"')
            
            
            price = query_presto(prediction)
            #st.session_state['price']  = st.session_state['price']  + price
            st.metric(label="SQL Return (Value in EUR)", value=price)

            st.metric(label="Accurracy", value=predication_value)

            new_row = pd.Series({'Amount':'1', 'Product':prediction, 'price': float(price)})  
            df = append_row(df, new_row) 
            df.to_csv(file_name, encoding='utf-8', index=False)

            with grid[0][2]:
                placeholder.data_editor(df,use_container_width=True)

            with grid[2][2]: 
                total = df['price'].sum()
                total = "{:.2f}".format(total)
                placeholder_price.title(str("Total: " + str(total) + " USD"))

            upload_file_to_s3('image.jpg')

        else:
            st.title("You found the coupon!!!   You get 50% discount!!!!")
            with grid[2][2]: 
                total_new = float(total) * 0.5
                total_new = "{:.2f}".format(total_new)
                placeholder_price.title(str("reduced price: " + str(total_new) + " USD"))
            upload_file_to_s3('image.jpg')

           

# Run the app
if __name__ == '__main__':
    app()

