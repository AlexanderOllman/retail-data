from flask import Flask, render_template, request, Response
import cv2
import numpy as np
import os
import requests
import json
import logging
import requests
from tensorflow.keras.preprocessing.image import load_img, img_to_array
import numpy as np
import os

logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger(__name__)

# Create a file handler and set its level to DEBUG
log_file_path = os.path.join(os.path.expanduser("~"), "app_log.txt")
file_handler = logging.FileHandler(log_file_path)
file_handler.setLevel(logging.DEBUG)

# Create a formatter and set the formatter for the handler
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)

# Add the file handler to the logger
logger.addHandler(file_handler)



DOMAIN_NAME = "svc.cluster.local"
NAMESPACE = open("/var/run/secrets/kubernetes.io/serviceaccount/namespace", "r").read() 
DEPLOYMENT_NAME = "retail-experiment"
MODEL_NAME = DEPLOYMENT_NAME
SVC = f'{DEPLOYMENT_NAME}-predictor.{NAMESPACE}.{DOMAIN_NAME}'
URL = f"http://{SVC}/v1/models/{MODEL_NAME}:predict"


app = Flask(__name__)

# Sample prices for items
item_prices = {
    "banana": 0.50,
    "apple": 0.75,
    "orange": 1.00
}

def preprocess_image(img):
    # Load the image
    img = img.resize((224, 224))
    img_array = img_to_array(img)
    img_array = img_array / 255.0
    img_array = np.expand_dims(img_array, axis=0)

    return img_array

def format_data(data):
    # Convert the NumPy array to a list
    data_list = data.tolist()
    
    # Format the list as a JSON string
    data_formatted = json.dumps(data_list)
    
    # Create a JSON request string with the formatted data
    json_request = '{{ "instances" : {} }}'.format(data_formatted)
    
    return json_request

def detect(image):
    
    img_array = preprocess_image(image)

    data = format_data(img_array)

    headers = {"Authorization": request.headers.get("authorization")}
    # Make the POST request
    response = requests.post(URL, data=data, headers=headers, verify=False)
    logger.warning(response.text)
    logger.warning(response.content.decode('utf-8'))

    response_data = response.json()
    predictions = response_data['predictions']
    formatted_predictions = [[round(pred * 100, 2) for pred in prediction] for prediction in predictions]

    labels = {'apple': 0, 'banana': 1, 'carrot': 2, 'cucumber': 3, 'lemon': 4, 'orange': 5}
    labels = dict((v, k) for k, v in labels.items())

    print("\nTranslated Predictions:")
    for label, prob in zip(labels, formatted_predictions[0]):
        print(f"- {label}: \t{prob}%")

    # Get the predicted label
    predicted_label_index = np.argmax(formatted_predictions)
    predicted_label = labels[predicted_label_index]

    # return "\nPredicted class label:", predicted_label, "with", formatted_predictions[0][predicted_label_index], "%"
    return predicted_label

def generate_frames():
    camera = cv2.VideoCapture(0)
    while True:
        success, frame = camera.read()
        if not success:
            break
        else:
            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/add_item', methods=['POST'])
def add_item():
    item = request.form['item']
    if item in item_prices:
        item_price = item_prices[item]
        return {'item': item, 'price': item_price}
    else:
        return {'error': 'Item not found'}, 404

@app.route('/save_frame', methods=['POST'])
def save_frame():
    camera = cv2.VideoCapture(0)
    success, frame = camera.read()
    if success:
        cv2.imwrite('frame.jpg', frame)
        detected_item = detect()
        if detected_item:
            item_price = item_prices.get(detected_item)
            if item_price:
                return {'item': detected_item, 'price': item_price}
            else:
                return {'error': 'Price not found for detected item'}, 500
        else:
            return {'error': 'No item detected in the frame'}, 500
    else:
        return {'error': 'Failed to save frame'}, 500
if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0", port=8080)
